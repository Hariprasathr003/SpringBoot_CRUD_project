package com.example.demo_project;

import org.springframework.data.repository.CrudRepository;


public interface User_Dao  extends CrudRepository<User,Integer> {

}
