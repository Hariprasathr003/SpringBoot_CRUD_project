package com.example.demo_project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class Usercontroller {
	
	@Autowired
	User_Dao userdao;
@RequestMapping("intro")
	public String Userm1() {
	return "intro.jsp";	
	}
@RequestMapping("Adduser")
public String adduser(User user) {
	userdao.save(user);
	return "intro.jsp";
	}


@RequestMapping("Getuser")
public ModelAndView Getuser(@RequestParam int id) {
	ModelAndView mav=new ModelAndView("showuser.jsp");
	 User user= userdao.findById(id).orElse(new User());
	 mav.addObject(user);
	 return mav;
}

@RequestMapping("Updateuser")
public ModelAndView Updateuser(User user) {
	ModelAndView mav=new ModelAndView("Update.jsp");
	 user= userdao.findById(user.getId()).orElse(new User());
	 userdao.deleteById(user.getId()); 
	 mav.addObject(user);
	 return mav;
}

@RequestMapping("Deleteuser")
public ModelAndView Deleteuser(@RequestParam int id) {
	ModelAndView mav=new ModelAndView("Deleteuser.jsp");
	 User user= userdao.findById(id).orElse(new User());
	 userdao.deleteById(id); 
	 mav.addObject(user);
	 return mav;
}
	
}
