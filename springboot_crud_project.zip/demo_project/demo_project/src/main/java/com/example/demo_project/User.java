package com.example.demo_project;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="tablename")

public class User {
		@Override
	public String toString() {
		return "User [Name=" + Name + "]";
	}
		@Id
		private int id;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String Name;
		

	}


