package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Studententity {
	public Studententity() {
		super();
	}
	@Id
	
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Studententity(int id, String name, String dep, int ph, String sts) {
		super();
		this.id = id;
		this.name = name;
		this.dep = dep;
		this.ph = ph;
		this.sts = sts;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDep() {
		return dep;
	}
	public void setDep(String dep) {
		this.dep = dep;
	}
	public int getPh() {
		return ph;
	}
	public void setPh(int ph) {
		this.ph = ph;
	}
	public String getSts() {
		return sts;
	}
	public void setSts(String sts) {
		this.sts = sts;
	}
	private String name;
	private String dep;
	private int ph;
	private String sts;
	

}
